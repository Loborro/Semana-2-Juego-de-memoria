//: Playground - noun: a place where people can play

import UIKit

var rango = 1...100

for numero in rango{
    
    if numero % 5 == 0 {
    
        print("\(numero) Bingo")
        
    }
    
    else if numero % 2 == 0 {
    
        print("\(numero) Par")
        
    }
    
    else if numero % 2 != 0 {
        
        print("\(numero) impar")
        
    }

    
    
    switch numero {
    
    case 30...40:
        print ("\(numero) Viva Swift")
        
    default:
        print("")
    
    }

}